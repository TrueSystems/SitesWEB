Imports System.Data.SqlClient
Imports System.Text
Imports System.Web.Mail
Imports System.Text.RegularExpressions
Module Funcoes
    '----------------------------------------------------------------------------------
    ' Procedimento: ValidaCPFCNPJ
    ' Autor: Marcelo Menezes Neves
    ' Data: 20/05/2002
    ' Prop�sito: Valida o CPF e o CNPJ informado
    ' Par�metros de Entrada:
    ' Par�metros de Sa�da:
    ' Data �ltima Atualiza��o: 20/05/2002
    ' Autor �ltima Atualiza��o: Marcelo Menezes Neves
    '----------------------------------------------------------------------------------
    Public Function ValidarCPFCNPJ(ByVal lsCPFCNPJ As String, ByVal lsTipo As String) As Boolean

        On Error Resume Next

        If lsCPFCNPJ.Length <> 11 And lsCPFCNPJ.Length <> 14 Then
            Return False
        End If

        Dim lvDigitos(14), llSoma As Long, llResultado1 As Long, llResultado2 As Long

        Select Case lsTipo

            Case "CPF"

                lvDigitos(1) = CInt(Mid(lsCPFCNPJ, 1, 1))
                lvDigitos(2) = CInt(Mid(lsCPFCNPJ, 2, 1))
                lvDigitos(3) = CInt(Mid(lsCPFCNPJ, 3, 1))
                lvDigitos(4) = CInt(Mid(lsCPFCNPJ, 4, 1))
                lvDigitos(5) = CInt(Mid(lsCPFCNPJ, 5, 1))
                lvDigitos(6) = CInt(Mid(lsCPFCNPJ, 6, 1))
                lvDigitos(7) = CInt(Mid(lsCPFCNPJ, 7, 1))
                lvDigitos(8) = CInt(Mid(lsCPFCNPJ, 8, 1))
                lvDigitos(9) = CInt(Mid(lsCPFCNPJ, 9, 1))
                lvDigitos(10) = CInt(Mid(lsCPFCNPJ, 10, 1))
                lvDigitos(11) = CInt(Mid(lsCPFCNPJ, 11, 1))
                llSoma = 10 * lvDigitos(1) + 9 * lvDigitos(2) + 8 * lvDigitos(3) + 7 * lvDigitos(4) + 6 * lvDigitos(5) + 5 * lvDigitos(6) + 4 * lvDigitos(7) + 3 * lvDigitos(8) + 2 * lvDigitos(9)
                llSoma = llSoma - (11 * (Int(llSoma / 11)))
                If llSoma = 0 Or llSoma = 1 Then
                    llResultado1 = 0
                Else
                    llResultado1 = 11 - llSoma
                End If
                If llResultado1 = lvDigitos(10) Then
                    llSoma = lvDigitos(1) * 11 + lvDigitos(2) * 10 + lvDigitos(3) * 9 + lvDigitos(4) * 8 + lvDigitos(5) * 7 + lvDigitos(6) * 6 + lvDigitos(7) * 5 + lvDigitos(8) * 4 + lvDigitos(9) * 3 + lvDigitos(10) * 2
                    llSoma = llSoma - (11 * (Int(llSoma / 11)))
                    If llSoma = 0 Or llSoma = 1 Then
                        llResultado2 = 0
                    Else
                        llResultado2 = 11 - llSoma
                    End If
                    If llResultado2 = lvDigitos(11) Then
                        Return True
                    Else
                        Return False
                    End If
                Else
                    Return False
                End If

            Case "CNPJ"

                lvDigitos(1) = CInt(Mid(lsCPFCNPJ, 1, 1))
                lvDigitos(2) = CInt(Mid(lsCPFCNPJ, 2, 1))
                lvDigitos(3) = CInt(Mid(lsCPFCNPJ, 3, 1))
                lvDigitos(4) = CInt(Mid(lsCPFCNPJ, 4, 1))
                lvDigitos(5) = CInt(Mid(lsCPFCNPJ, 5, 1))
                lvDigitos(6) = CInt(Mid(lsCPFCNPJ, 6, 1))
                lvDigitos(7) = CInt(Mid(lsCPFCNPJ, 7, 1))
                lvDigitos(8) = CInt(Mid(lsCPFCNPJ, 8, 1))
                lvDigitos(9) = CInt(Mid(lsCPFCNPJ, 9, 1))
                lvDigitos(10) = CInt(Mid(lsCPFCNPJ, 10, 1))
                lvDigitos(11) = CInt(Mid(lsCPFCNPJ, 11, 1))
                lvDigitos(12) = CInt(Mid(lsCPFCNPJ, 12, 1))
                lvDigitos(13) = CInt(Mid(lsCPFCNPJ, 13, 1))
                lvDigitos(14) = CInt(Mid(lsCPFCNPJ, 14, 1))
                llSoma = lvDigitos(1) * 5 + lvDigitos(2) * 4 + lvDigitos(3) * 3 + lvDigitos(4) * 2 + lvDigitos(5) * 9 + lvDigitos(6) * 8 + lvDigitos(7) * 7 + lvDigitos(8) * 6 + lvDigitos(9) * 5 + lvDigitos(10) * 4 + lvDigitos(11) * 3 + lvDigitos(12) * 2
                llSoma = llSoma - (11 * (Int(llSoma / 11)))
                If llSoma = 0 Or llSoma = 1 Then
                    llResultado1 = 0
                Else
                    llResultado1 = 11 - llSoma
                End If
                If llResultado1 = lvDigitos(13) Then
                    llSoma = lvDigitos(1) * 6 + lvDigitos(2) * 5 + lvDigitos(3) * 4 + lvDigitos(4) * 3 + lvDigitos(5) * 2 + lvDigitos(6) * 9 + lvDigitos(7) * 8 + lvDigitos(8) * 7 + lvDigitos(9) * 6 + lvDigitos(10) * 5 + lvDigitos(11) * 4 + lvDigitos(12) * 3 + lvDigitos(13) * 2
                    llSoma = llSoma - (11 * (Int(llSoma / 11)))
                    If llSoma = 0 Or llSoma = 1 Then
                        llResultado2 = 0
                    Else
                        llResultado2 = 11 - llSoma
                    End If
                    If llResultado2 = lvDigitos(14) Then
                        Return True
                    Else
                        Return False
                    End If
                Else
                    Return False
                End If

        End Select

    End Function
    Public Function FormataCNPJ(ByVal cnpj As String)
        Try
            FormataCNPJ = cnpj.Substring(0, 2) & "." & cnpj.Substring(2, 3) & "." & cnpj.Substring(5, 3) & "/" & cnpj.Substring(8, 4) & "-" & cnpj.Substring(12, 2)
        Catch ex As Exception
            FormataCNPJ = cnpj
        End Try

    End Function
    Public Function FormataCPF(ByVal CPF As String)
        Try
            FormataCPF = CPF.Substring(0, 3) & "." & CPF.Substring(3, 3) & "." & CPF.Substring(6, 3) & "-" & CPF.Substring(9, 2)
        Catch ex As Exception
            FormataCPF = CPF
        End Try


    End Function
    Public Function ValidarEMail(ByVal lsEMail As String) As Boolean

        Dim liPosicaoArroba As Short
        Dim RegEx2 As New Regex("^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})")


        Try
            If RegEx2.IsMatch(lsEMail) Then
                Return True
            Else
                Return False
            End If

        Catch ex As Exception
            Return False

        End Try

    End Function
    Public Function LeConnectionStringCriptografada() As String

        Dim loSB As New StringBuilder
        Dim gsSecretKey As String = "1edw32e4"
        Dim cn As String
        '------------------------
        ' Monta CONNECTION STRING
        '------------------------

        'Instancia classe de encripta��o
        Dim clsEncriptacao As clsEncryption128 = New clsEncryption128
        'L� configura��es do WEB.CONFIG
        cn = "data source=" & clsEncriptacao.Decrypt(ConfigurationSettings.AppSettings.Get("ServidorBD"), gsSecretKey)
        cn = cn & ";initial catalog=" & clsEncriptacao.Decrypt(ConfigurationSettings.AppSettings.Get("NomeBD"), gsSecretKey)
        cn = cn & ";persist security info=false"
        cn = cn & ";packet size=4096;user id=" & clsEncriptacao.Decrypt(ConfigurationSettings.AppSettings.Get("UsuarioBD"), gsSecretKey)
        cn = cn & ";PWD=" & clsEncriptacao.Decrypt(ConfigurationSettings.AppSettings.Get("SenhaBD"), gsSecretKey)
        cn = cn & ";Connect Timeout=40"

        clsEncriptacao = Nothing

        LeConnectionStringCriptografada = cn

    End Function

#Region "Exemplos - Nao deixe de ver"
    Public Function ExemploDeEnvioDeEMail()

        Dim CorpoEMailFornecedor As New StringBuilder
        CorpoEMailFornecedor.Append("<html><head><title>Pedido</title></head><body><font face='Arial'>")
        CorpoEMailFornecedor.Append("<p>Pedido Novo.</p>")
        CorpoEMailFornecedor.Append("<p>Este pedido foi enviado pela for�a de vendas, por favor n�o responda este e-mail</p>")
        CorpoEMailFornecedor.Append("<p><b>Total do Pedido : </b></p>")
        CorpoEMailFornecedor.Append("</font></body></html>")

        Dim MailFornecedor As New System.Web.Mail.MailMessage
        MailFornecedor.BodyFormat = Mail.MailFormat.Html
        MailFornecedor.Subject = "Pedido pWap"
        MailFornecedor.From = "info@truesys.com"
        MailFornecedor.To = "info@truesys.com"
        MailFornecedor.Body = CorpoEMailFornecedor.ToString
        SmtpMail.SmtpServer = "localhost"
        SmtpMail.Send(MailFornecedor)

    End Function

    Public Function EsqueletoDeAcessoADados()

        Dim SQLConnection As SqlClient.SqlConnection
        Dim SQLcmd As SqlCommand = New SqlCommand
        Dim SQLrdr As SqlDataReader

        Try

            SQLConnection = New SqlConnection("ConnectionString")
            SQLConnection.Open()

            SQLcmd.Connection = SQLConnection
            SQLcmd.CommandType = CommandType.StoredProcedure
            SQLcmd.CommandText = "wap_obs_filtrar"

            SQLcmd.Parameters.Clear()
            SQLcmd.Parameters.Add("@Ambiente", "")
            SQLcmd.Parameters.Add("@codigo_usuario", "")

            SQLrdr = SQLcmd.ExecuteReader

            If SQLrdr.HasRows Then
                While (SQLrdr.Read)
                    'loopa no datareader
                End While
            End If

            SQLrdr.Close()

        Catch ex As Exception
            'Exemplo de utilizacao do Log
            'Dim er As New LogDeErro
            'er.OcorreuErro(ConnectionString, Now.ToString("dd/MM/yyyy hh:mm:ss"), CodigoUsuarioCorrente, NomeUsuarioCorrente, Usuario, Ambiente, ex, ServidorSMTP, EMailTruesysWAP)


        Finally
            SQLrdr.Close()
            SQLrdr = Nothing
            SQLConnection.Close()
            SQLConnection = Nothing
            SQLcmd = Nothing
        End Try

    End Function

#End Region

End Module
