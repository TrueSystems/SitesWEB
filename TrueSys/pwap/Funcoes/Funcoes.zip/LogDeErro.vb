Imports System.IO
Imports System.Web.Mail
Public Class LogDeErro

    Public Sub OcorreuErro(ByVal lsConnectionString As String, _
       ByVal lsDataHora As String, _
       ByVal lsCodigoUsuarioCorrente As String, _
       ByVal lsNomeUsuarioCorrente As String, _
       ByVal lsUserNameUsuarioCorrente As String, _
       ByVal lsCodigoAmbiente As String, _
       ByRef loexcErro As Exception, _
       ByVal lsSMTPServer As String, _
       ByVal lsMailTo As String)

        Dim lsErroOcorrido As String
        Dim lomailSpoolEmail As New MailMessage

        Try

            If loexcErro.StackTrace Is Nothing Then
                lsErroOcorrido = "Data/Hora................: " & lsDataHora & vbCrLf
                lsErroOcorrido &= "Ambiente.................: " & lsCodigoAmbiente & vbCrLf
                lsErroOcorrido &= "C�digo Usu�rio Corrente..: " & lsCodigoUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "Nome Usu�rio Corrente....: " & lsNomeUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "UserName Usu�rio Corrente: " & lsUserNameUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "Descri��o................: " & loexcErro.Message & vbCrLf
            Else
                lsErroOcorrido = "Data/Hora................: " & lsDataHora & vbCrLf
                lsErroOcorrido &= "Ambiente.................: " & lsCodigoAmbiente & vbCrLf
                lsErroOcorrido &= "C�digo Usu�rio Corrente..: " & lsCodigoUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "Nome Usu�rio Corrente....: " & lsNomeUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "UserName Usu�rio Corrente: " & lsUserNameUsuarioCorrente & vbCrLf
                lsErroOcorrido &= "M�todo...................: " & loexcErro.TargetSite().Name & vbCrLf
                lsErroOcorrido &= "Descri��o................: " & loexcErro.Message & vbCrLf
                lsErroOcorrido &= "StackTrace...............: " & vbCrLf & loexcErro.StackTrace & vbCrLf
                lsErroOcorrido &= "Origem...................: " & loexcErro.Source & vbCrLf
            End If


            'Envia e-mail para suporte da True Systems
            SmtpMail.SmtpServer = lsSMTPServer
            lomailSpoolEmail.BodyFormat = MailFormat.Text
            lomailSpoolEmail.Priority = MailPriority.High
            lomailSpoolEmail.From = lsMailTo
            lomailSpoolEmail.To = lsMailTo
            lomailSpoolEmail.Subject = "CustomerLink WAP Lite (CLMW) - Erro no Sistema"
            lomailSpoolEmail.Body = lsErroOcorrido

            'Envia o e-mail
            SmtpMail.Send(lomailSpoolEmail)

        Catch ex As Exception
            Err.Clear()
        End Try


        Try
            'Grava Arquivo de log de erro
            Dim lsPath As String = AppPath() & "LOG/" & Guid.NewGuid.ToString & ".txt"
            Dim loLog As New StreamWriter(lsPath)
            loLog.Write(lsErroOcorrido)
            loLog.Flush()
            loLog.Close()
            loLog = Nothing
        Catch ex As Exception
            Err.Clear()
        End Try
        
    End Sub

    Public Function AppPath()

        Return AppDomain.CurrentDomain.BaseDirectory

    End Function



End Class
